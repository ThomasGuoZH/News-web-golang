package control

import (
	"backend/jwtpart"
	"backend/models"
	"backend/my_sql"
	"backend/response"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
	//"github.com/go-sql-driver/mysql"

	//"go.uber.org/zap"
	"golang.org/x/crypto/bcrypt"
)

func RegisterHandler(c *gin.Context) {
	/*var user_register *models.RegisterForm
	//操作*/
	name := c.PostForm("name")
	password := c.PostForm("password")
	phone := c.PostForm("phone")
	if len(phone) != 11 {
		response.Response(c, http.StatusUnprocessableEntity, 422, nil, "The phone num must be 11 digits!")
		return
	}
	if len(password) < 6 {
		response.Response(c, http.StatusUnprocessableEntity, 422, nil, "Password not less 6 digits!")
		return
	}
	hasedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost) // 创建用户的时候要加密用户的密码
	if err != nil {
		response.Response(c, http.StatusInternalServerError, 500, nil, "Hased password error!")
		return
	}
	//暂时省略了一些判断标准

	user := models.User{
		Name:     name,
		Password: string(hasedPassword),
		Phone:    phone,
	}
	my_sql.DB.Create(&user)
	response.Succces(c, nil, "Register success!")
}

func LoginHandler(c *gin.Context) {
	// 1、获取请求参数及参数校验
	phone := c.PostForm("phone") // 获取参数
	password := c.PostForm("password")
	if phone == "" {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "Phone num not null!"})
		return
	}
	if password == "" {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "Password not null!"})
		return
	}
	if len(phone) != 11 { // 数据验证
		c.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "Phone num must 11 digits!"})
		return
	}
	if len(password) < 6 {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "Password len not less 6 bigits!"})
		return
	}
	var user models.User // 判断手机号是否存在
	my_sql.DB.Where("phone = ?", phone).First(&user)
	if user.ID == 0 {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "User not exist!"})
		return
	}
	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password)); err != nil { // 判断密码是否正确
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "msg": "password err!"})
	}
	token, err := jwtpart.ReleaseToken(user) // 发放token
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "System err!"})
		log.Printf("token generate error:%v", err)
		return
	}
	response.Succces(c, gin.H{"token": token}, "Login success!")
}
